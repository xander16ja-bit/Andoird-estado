package com.estado.celular;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 15, 28);
    private static final int CARD = Color.rgb(17, 30, 49);
    private static final int STROKE = Color.rgb(39, 61, 83);
    private static final int WHITE = Color.rgb(238, 247, 255);
    private static final int MUTED = Color.rgb(152, 174, 195);
    private static final int CYAN = Color.rgb(80, 216, 255);
    private static final int GREEN = Color.rgb(99, 239, 177);
    private LinearLayout content;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        build();
    }
    @Override public void onResume() {
        super.onResume();
        if (content != null) build();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable background(int color, int borderColor, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (borderColor != 0) d.setStroke(dp(1), borderColor);
        return d;
    }

    private TextView t(String value, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(true);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private void addSpace(LinearLayout parent, int height) {
        View v = new View(this);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private LinearLayout card() {
        LinearLayout l = vertical();
        l.setPadding(dp(18), dp(16), dp(18), dp(16));
        l.setBackground(background(CARD, STROKE, 18));
        return l;
    }

    private void addCard(LinearLayout box) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(12);
        content.addView(box, lp);
    }

    private void section(String title) {
        TextView v = t(title, 19, WHITE, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(15); lp.bottomMargin = dp(10);
        content.addView(v, lp);
    }

    private void detail(LinearLayout box, String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(7), 0, dp(7));
        TextView key = t(label, 14, MUTED, false);
        TextView val = t(value == null || value.isEmpty() ? "No disponible" : value, 14, WHITE, true);
        val.setGravity(Gravity.END);
        row.addView(key, new LinearLayout.LayoutParams(0, -2, 0.43f));
        row.addView(val, new LinearLayout.LayoutParams(0, -2, 0.57f));
        box.addView(row);
    }

    private void meter(LinearLayout card, int percent, int color) {
        LinearLayout track = new LinearLayout(this);
        track.setBackground(background(Color.rgb(42, 62, 81), 0, 100));
        LinearLayout.LayoutParams trackParams = new LinearLayout.LayoutParams(-1, dp(8));
        trackParams.topMargin = dp(12);
        card.addView(track, trackParams);
        View bar = new View(this);
        bar.setBackground(background(color, 0, 100));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, -1, Math.max(0, Math.min(100, percent)));
        track.addView(bar, bp);
        View rest = new View(this);
        track.addView(rest, new LinearLayout.LayoutParams(0, -1, 100 - Math.max(0, Math.min(100, percent))));
    }

    private String gigabytes(long bytes) {
        if (bytes <= 0) return "No disponible";
        return String.format(Locale.getDefault(), "%.1f GB", bytes / 1_000_000_000d);
    }

    private String statusBattery(int status) {
        switch(status) {
            case BatteryManager.BATTERY_STATUS_CHARGING: return "Cargando";
            case BatteryManager.BATTERY_STATUS_FULL: return "Carga completa";
            case BatteryManager.BATTERY_STATUS_DISCHARGING: return "Descargando";
            case BatteryManager.BATTERY_STATUS_NOT_CHARGING: return "Conectada, sin cargar";
            default: return "Desconocido";
        }
    }

    private String healthBattery(int health) {
        switch (health) {
            case BatteryManager.BATTERY_HEALTH_GOOD: return "Normal (según Android)";
            case BatteryManager.BATTERY_HEALTH_OVERHEAT: return "Temperatura elevada";
            case BatteryManager.BATTERY_HEALTH_DEAD: return "Batería deteriorada";
            case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE: return "Voltaje elevado";
            case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE: return "Fallo reportado";
            case BatteryManager.BATTERY_HEALTH_COLD: return "Temperatura baja";
            default: return "No disponible";
        }
    }

    private String thermal() {
        if (Build.VERSION.SDK_INT < 29) return "No disponible en este Android";
        PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
        if (power == null) return "No disponible";
        switch(power.getCurrentThermalStatus()) {
            case PowerManager.THERMAL_STATUS_NONE: return "Normal";
            case PowerManager.THERMAL_STATUS_LIGHT: return "Calentamiento leve";
            case PowerManager.THERMAL_STATUS_MODERATE: return "Calentamiento moderado";
            case PowerManager.THERMAL_STATUS_SEVERE: return "Calentamiento alto";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "Calentamiento crítico";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "Emergencia térmica";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "Apagado térmico";
            default: return "No disponible";
        }
    }

    private void build() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        content = vertical();
        content.setPadding(dp(20), dp(28), dp(20), dp(32));
        scroll.addView(content);
        setContentView(scroll);

        TextView brand = t("◉  ESTADO CELULAR", 13, CYAN, true);
        content.addView(brand);
        addSpace(content, 12);
        TextView title = t("Tu teléfono,\na simple vista.", 30, WHITE, true);
        content.addView(title);
        addSpace(content, 7);
        TextView subtitle = t("Información real de Android, sin cuentas y sin Internet.", 14, MUTED, false);
        content.addView(subtitle);
        addSpace(content, 18);

        LinearLayout hero = card();
        hero.setBackground(background(Color.rgb(19, 52, 69), Color.rgb(35, 105, 125), 20));
        hero.addView(t("DISPOSITIVO", 12, CYAN, true));
        addSpace(hero, 7);
        hero.addView(t(Build.MANUFACTURER + " " + Build.MODEL, 24, WHITE, true));
        hero.addView(t("Android " + Build.VERSION.RELEASE + "   ·   API " + Build.VERSION.SDK_INT, 15, MUTED, false));
        addCard(hero);

        section("Batería");
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        LinearLayout b = card();
        if (battery == null) {
            b.addView(t("No se puede consultar la batería", 16, MUTED, false));
        } else {
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int percent = scale > 0 && level >= 0 ? Math.round(level * 100f / scale) : -1;
            b.addView(t(percent >= 0 ? percent + "%" : "Sin datos", 34, GREEN, true));
            b.addView(t(statusBattery(battery.getIntExtra(BatteryManager.EXTRA_STATUS, 1)), 14, MUTED, false));
            if (percent >= 0) meter(b, percent, GREEN);
            addSpace(b, 12);
            detail(b, "Salud reportada", healthBattery(battery.getIntExtra(BatteryManager.EXTRA_HEALTH, 1)));
            int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            if (temp != Integer.MIN_VALUE) detail(b, "Temperatura", String.format(Locale.getDefault(), "%.1f °C", temp / 10f));
            int voltage = battery.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
            if (voltage > 0) detail(b, "Voltaje", String.format(Locale.getDefault(), "%.2f V", voltage / 1000f));
        }
        addCard(b);

        section("Memoria y almacenamiento");
        LinearLayout mem = card();
        ActivityManager manager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (manager != null) {
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(info);
            detail(mem, "RAM total", gigabytes(info.totalMem));
            detail(mem, "RAM libre (aprox.)", gigabytes(info.availMem));
            detail(mem, "Uso de RAM (aprox.)", gigabytes(Math.max(0, info.totalMem - info.availMem)));
            detail(mem, "Memoria baja", info.lowMemory ? "Android lo advierte" : "Sin alerta de Android");
        }
        File storage = Environment.getExternalStorageDirectory();
        long total = storage.getTotalSpace();
        long free = storage.getUsableSpace();
        if (total > 0) {
            int usedPercent = (int) Math.round(100.0 * (total - free) / total);
            addSpace(mem, 9);
            mem.addView(t("ALMACENAMIENTO INTERNO", 12, CYAN, true));
            meter(mem, usedPercent, CYAN);
            addSpace(mem, 9);
            detail(mem, "Capacidad", gigabytes(total));
            detail(mem, "Libre", gigabytes(free));
            detail(mem, "Ocupado", usedPercent + "%");
        } else {
            detail(mem, "Almacenamiento", "No disponible");
        }
        addCard(mem);

        section("Sistema operativo");
        LinearLayout sys = card();
        detail(sys, "Android", Build.VERSION.RELEASE);
        detail(sys, "Nivel API", String.valueOf(Build.VERSION.SDK_INT));
        detail(sys, "Seguridad", Build.VERSION.SDK_INT >= 23 ? Build.VERSION.SECURITY_PATCH : "No disponible");
        detail(sys, "Fabricante", Build.MANUFACTURER);
        detail(sys, "Modelo", Build.MODEL);
        detail(sys, "Hardware", Build.HARDWARE);
        detail(sys, "Arquitectura", Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0 ? Build.SUPPORTED_ABIS[0] : "Desconocida");
        detail(sys, "Núcleos disponibles", String.valueOf(Runtime.getRuntime().availableProcessors()));
        addCard(sys);

        section("Estado actual");
        LinearLayout state = card();
        detail(state, "Temperatura del sistema", thermal());
        long minutes = SystemClock.elapsedRealtime() / 60000;
        detail(state, "Tiempo encendido", (minutes / 1440) + "d " + ((minutes % 1440) / 60) + "h " + (minutes % 60) + "m");
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        detail(state, "Pantalla (app)", metrics.widthPixels + " × " + metrics.heightPixels + " px");
        detail(state, "Actualizado", new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()));
        addCard(state);

        TextView refresh = t("↻   Actualizar datos", 16, BG, true);
        refresh.setGravity(Gravity.CENTER);
        refresh.setPadding(dp(14), dp(15), dp(14), dp(15));
        refresh.setBackground(background(CYAN, 0, 14));
        refresh.setOnClickListener(v -> build());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = dp(10);
        content.addView(refresh, rp);
        addSpace(content, 16);
        TextView note = t("Privacidad: no pide permisos, no sube datos y funciona sin conexión. Los valores son los que Android permite consultar: no constituyen un diagnóstico técnico de fallas físicas ni un porcentaje de desgaste de batería.", 12, MUTED, false);
        content.addView(note);
    }
}
