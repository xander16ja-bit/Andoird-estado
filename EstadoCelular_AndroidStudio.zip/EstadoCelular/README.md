# Estado Celular — Android

App Android nativa en español, sin anuncios, sin cuenta, sin acceso a Internet y sin permisos peligrosos.

## Qué muestra
- Marca, modelo, Android, nivel API y parche de seguridad.
- Batería: porcentaje, carga, salud **reportada por Android**, temperatura y voltaje (si el teléfono los proporciona).
- Memoria RAM disponible/total y almacenamiento interno libre/total.
- Hardware, arquitectura, núcleos disponibles, estado térmico si Android lo admite, tiempo encendido y tamaño del área de pantalla de la app.
- Botón «Actualizar datos».

### Importante
Una app normal **no puede certificar** si un teléfono tiene daños internos ni medir con precisión el desgaste de la batería en todos los modelos. «Salud reportada» utiliza los estados publicados por Android; «Normal» no significa «batería al 100 % de salud».

## Cómo instalar en tu Android
1. En un ordenador, instala **Android Studio**.
2. Descomprime este archivo y abre **EstadoCelular** con `File > Open`.
3. Deja sincronizar Gradle; Android Studio descargará el SDK/Gradle necesarios si no los tienes.
4. Conecta tu móvil por USB y ejecútalo con **Run**, o usa **Build > Build APK(s)** para generar el APK.
5. El APK de desarrollo normalmente se encontrará en `app/build/outputs/apk/debug/app-debug.apk`. Pásalo al móvil e instálalo siguiendo las indicaciones de Android.

Configuración: Gradle plugin 8.7.3 / Gradle 8.9 / Java 17 / SDK 35 / Android mínimo 6.0 (API 23). El proyecto no incluye un APK compilado ni un wrapper JAR: este entorno no dispone de Android SDK/Gradle para generarlos. Android Studio puede importar el proyecto y descargar dependencias.

## Privacidad
No hay permiso `INTERNET`, no se recopilan datos personales y no se envían datos a ningún servidor. La app muestra únicamente información del equipo en el propio dispositivo.
